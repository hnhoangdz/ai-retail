# hehe > 2023-02-26 5:51pm
https://universe.roboflow.com/vti-uwpfw/hehe-ldth6

Provided by a Roboflow user
License: CC BY 4.0

